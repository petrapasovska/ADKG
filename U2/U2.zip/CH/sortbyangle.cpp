#include "sortbyangle.h"

sortbyangle::sortbyangle()
{

}
