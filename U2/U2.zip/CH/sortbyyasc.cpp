#include "sortbyyasc.h"

sortByYAsc::sortByYAsc()
{

}
